const db = wx.cloud.database()
Page({
  data:{
    dataObj:""
  },
  //获取数据库内容
   getData(){
   db.collection("items_inform").where({
     item_feature:"丑的一比"
   }).get()
   .then(res=>{
     console.log(res)
   })
   },

   //增加数据项
  addData(){
    wx.showLoading({
      title: '数据加载中......',
      mask:true
    })
     db.collection("items_inform").add({
       data:{
         item_feature:"啥玩意哦"
       } 
     }).then(res=>{
      console.log(res) 
      wx.hideLoading()
     })
  },
  btnSub(res){
    var resValu = res.detail.value
    db.collection("items_inform").add({
      data:resValu
    }).then(res=>{
     console.log(res) 
    })
  },
updateData(){
  db.collection("items_inform").doc("cbddf0af60be0ca70ed20b43615817ae").update({
    data:{
      item_feature:"heh"
    }
  }).then(res=>{
    console.log(res)
  })
},

delData(){
  db.collection("items_inform")
  .doc("79550af260be125c1dcae6ae5834008f")
  .remove()
  .then(res=>{
    console.log(res)
  })
},
  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})