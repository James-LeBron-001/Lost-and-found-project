// miniprogram/pages/demo1/demo1.js
const db = wx.cloud.database();
const _=db.command;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  //command  按照给定数据的值来查找数据
  getDataCommand(){
    db.collection("items_inform")
    .where({
      item_feature:_.neq("丑的一比")
    })
    .get()
    .then(res=>{
     console.log(res)
     this.setData({
       dataList:res.data
     })
    })
  },
//获取数据
getData(){
  db.collection("items_inform")
  .get()
  .then(res=>{
    this.setData({
      dataArr:res.data
    })
  })
},
  //统计个数
btnNum(){
  db.collection("items_inform").count()
  .then(res=>{
    console.log(res)
  })
},
//条件查询 skip(n)分页，跳过前n个数据
getLimiData(){
  db.collection("items_inform").limit(2).orderBy("item_findTime","asc").get()
  .then(res=>{
    console.log(res)
  })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   db.collection("items_inform").watch({
    onChange:res=>{
      console.log(res)
      //对数据进行一次覆盖
      this.setData({
        dataArr:res.docs
      })
    },
    onError:err=>{
      console.log(err)
    }
   })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})