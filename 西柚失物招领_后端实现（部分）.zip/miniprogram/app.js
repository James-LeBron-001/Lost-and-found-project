//app.js
App({
onLaunch: function(){
  wx.cloud.init({
    env:"test-3gsdqaxbe3fb020b"
  })
}
})
